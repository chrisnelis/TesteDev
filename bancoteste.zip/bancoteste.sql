-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.22-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para bd_teste
CREATE DATABASE IF NOT EXISTS `bd_teste` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `bd_teste`;

-- Copiando estrutura para tabela bd_teste.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `telefone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela bd_teste.cliente: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`id`, `nome`, `email`, `created_at`, `updated_at`, `telefone`) VALUES
	(2, 'João', 'joao@teste.com', NULL, NULL, '7777 7777'),
	(3, 'Maria', 'maria@maria', NULL, NULL, '2222 2222'),
	(4, 'Ricardo', 'ricardo@ricardo', NULL, NULL, '2222 2222'),
	(6, 'Fulano', 'fulano@teste.com', NULL, NULL, '0000 0000'),
	(7, 'Ciclano', 'ciclano@teste.com', NULL, NULL, '1010 0000');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

-- Copiando estrutura para tabela bd_teste.produto
CREATE TABLE IF NOT EXISTS `produto` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `telefone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela bd_teste.produto: ~12 rows (aproximadamente)
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` (`id`, `produto`, `valor`, `description`, `created_at`, `updated_at`, `telefone`) VALUES
	(7, 'Ionic', 90, '', NULL, NULL, NULL),
	(8, 'PHP', 100, '', NULL, NULL, NULL),
	(9, 'Javascript', 70, '', NULL, NULL, NULL),
	(12, 'flutter', 108, '', NULL, NULL, NULL),
	(13, 'PHP', 35, '', NULL, NULL, NULL),
	(14, 'PHP', 20, '', NULL, NULL, NULL),
	(16, 'Python', 200, '', NULL, NULL, NULL),
	(46, '', 0, '', NULL, NULL, NULL),
	(47, '', 0, '', NULL, NULL, NULL),
	(48, '', 0, '', NULL, NULL, NULL),
	(49, '', 0, '', NULL, NULL, NULL),
	(50, '', 0, '', NULL, NULL, NULL);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
